package com.example.flutter_application_1test

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
